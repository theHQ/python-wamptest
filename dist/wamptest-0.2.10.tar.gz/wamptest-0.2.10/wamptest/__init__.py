from wamptest import TestCase, main
